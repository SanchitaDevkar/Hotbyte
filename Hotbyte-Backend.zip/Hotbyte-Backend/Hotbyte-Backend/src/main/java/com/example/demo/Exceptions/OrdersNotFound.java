package com.example.demo.Exceptions;

public class OrdersNotFound extends RuntimeException {

	public OrdersNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
