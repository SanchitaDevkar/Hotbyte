package com.example.demo.Controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Model.Menu;
import com.example.demo.Model.Orders;
import com.example.demo.Model.Restaurant;
import com.example.demo.Services.RestaurantServ;
import com.example.demo.dto.LoginResponse;
import com.example.demo.dto.MenuResponse;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/restaurant")

@CrossOrigin("*")
public class RestaurantController {

    @Autowired
    private RestaurantServ restaurantServ;

   

    @PostMapping("/menu")
    public ResponseEntity<Menu> addMenu(HttpServletRequest request, @RequestBody Menu menu) {
        return ResponseEntity.ok(restaurantServ.AddMenu(request, menu));
    }

    @PutMapping("/menu/{menuId}")
    public ResponseEntity<Menu> updateMenu(
            HttpServletRequest request,
            @PathVariable int menuId,
            @RequestBody Menu updatedMenu) {
        return ResponseEntity.ok(restaurantServ.UpdateMenu(request, menuId, updatedMenu));
    }

    @DeleteMapping("/menu/{menuId}")
    public ResponseEntity<Map<String, String>> deleteMenu(HttpServletRequest request, @PathVariable int menuId) {
        restaurantServ.DeleteById(request, menuId);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Menu deleted successfully");

        return ResponseEntity.ok(response); 
    }


    @PutMapping("/menu/{menuId}/out-of-stock")
    public ResponseEntity<String> markOutOfStock(HttpServletRequest request, @PathVariable int menuId) {
        return ResponseEntity.ok(restaurantServ.UpdateOutOfStock(request, menuId));
    }

    @PutMapping("/menu/{menuId}/in-stock")
    public ResponseEntity<String> markInStock(HttpServletRequest request, @PathVariable int menuId) {
        return ResponseEntity.ok(restaurantServ.UpdateInStock(request, menuId));
    }

    @GetMapping("/menus")
    public ResponseEntity<List<Menu>> viewAllMenus(HttpServletRequest request) {
        return ResponseEntity.ok(restaurantServ.viewAllMenu(request));
    }
    @GetMapping("/menu/instock")
    public ResponseEntity<List<Menu>> viewallinstock(HttpServletRequest request){
    	return ResponseEntity.ok(restaurantServ.viewAllMenuByAvailableTrue(request));
    }
    @GetMapping("/menu/outstock")
    public ResponseEntity<List<Menu>> viewalloutstock(HttpServletRequest request){
    	return ResponseEntity.ok(restaurantServ.viewAllMenuByAvailablefalse(request));
    }
    
    

   

    @GetMapping("/orders")
    public ResponseEntity<List<Orders>> viewAllOrders(HttpServletRequest request) {
        return ResponseEntity.ok(restaurantServ.ViewAllOrder(request));
    }

    @GetMapping("/orders/pending")
    public ResponseEntity<List<Orders>> viewPendingOrders(HttpServletRequest request) {
        return ResponseEntity.ok(restaurantServ.ViewPendingOrder(request));
    }
    @GetMapping("/orders/processing")
    public ResponseEntity<List<Orders>> viewProcessingOrders(HttpServletRequest request) {
        return ResponseEntity.ok(restaurantServ.ViewProcessingOrder(request));
    }
    @GetMapping("/orders/outfordelivery")
    public ResponseEntity<List<Orders>> viewoutfordelivery(HttpServletRequest request) {
        return ResponseEntity.ok(restaurantServ.Viewoutfordelivery(request));
    }

    @GetMapping("/orders/history")
    public ResponseEntity<List<Orders>> viewDeliveredOrders(HttpServletRequest request) {
        return ResponseEntity.ok(restaurantServ.HistoryOfOrder(request));
    }

    @PutMapping("/orders/processing/{orderId}")
    public ResponseEntity<String> setOrderProcessing(HttpServletRequest request, @PathVariable int orderId) {
        return ResponseEntity.ok(restaurantServ.setOrderAsProcessing(request, orderId));
    }

    @PutMapping("/orders/{orderId}/delivered")
    public ResponseEntity<String> setOrderDelivered(HttpServletRequest request, @PathVariable int orderId) {
        return ResponseEntity.ok(restaurantServ.setOrderAsDelivery(request, orderId));
    }
    @PutMapping("/orders/{orderId}/outfordelivery")
    public ResponseEntity<String> setOrderoutfordelivery(HttpServletRequest request, @PathVariable int orderId) {
        return ResponseEntity.ok(restaurantServ.setOrderAsOutforDelivery(request, orderId));
    }
    @PutMapping("/orders/{orderId}/cancelled")
    public ResponseEntity<String> setcancelled(HttpServletRequest request, @PathVariable int orderId) {
        return ResponseEntity.ok(restaurantServ.setOrderAsCancel(request, orderId));
    }

    @GetMapping("/menu/{menuid}")
    public ResponseEntity<Optional<Menu>> getmenubyid(HttpServletRequest request,@PathVariable int menuid){
    	return ResponseEntity.ok(restaurantServ.getmenubyId(request, menuid));
    }
    
    
    @PutMapping("/restaurant/update")
    public ResponseEntity<Restaurant> updatetherestaurant(HttpServletRequest request,@RequestBody Restaurant restaurant){
    	return ResponseEntity.ok(restaurantServ.updateProfile(request, restaurant));
    }
    
    @GetMapping("/restaurant/profile")
    public ResponseEntity<Restaurant> getRestaurant(HttpServletRequest request){
    	return ResponseEntity.ok(restaurantServ.getprofileRes(request));
    }
}

