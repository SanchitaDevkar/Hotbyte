package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.Model.Menu;
import com.example.demo.Model.Enum.Category;
import com.example.demo.Model.Enum.DietaryType;
import com.example.demo.dto.MenuResponse;
@Repository
public interface MenuRepo extends JpaRepository<Menu,Integer> {

	List<Menu> findAllByRestaurantId(int resId);

	List<Menu> findByNameIgnoreCase(String name);


	List<Menu> findByCategory(Category category);


	List<Menu> findByCategoryAndNameContainingAndPriceBetween(
		    String category, String name, int minPrice, int maxPrice);
	List<Menu> findByNameContainingIgnoreCase(String name);

	List<Menu> findAllByRestaurantIdAndAvailable(int resId, boolean b);

	List<Menu> findByCategoryAndDietaryTypeAndPriceBetween(
		    Category category, DietaryType dietaryType, Double minPrice, Double maxPrice);

	List<Menu> findByCategoryAndPriceBetween(Category category, Double minPrice, Double maxPrice);

	List<Menu> findByDietaryTypeAndPriceBetween(DietaryType dietary, Double minPrice, Double maxPrice);

	List<Menu> findByPriceBetween(Double minPrice, Double maxPrice);




}
