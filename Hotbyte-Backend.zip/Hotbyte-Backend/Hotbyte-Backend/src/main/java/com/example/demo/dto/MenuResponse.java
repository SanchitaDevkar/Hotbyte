package com.example.demo.dto;

import com.example.demo.Model.Enum.Category;
import com.example.demo.Model.Enum.DietaryType;
import com.example.demo.Model.Enum.TasteInfo;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

public class MenuResponse {
    private int id;
    private String name;
    private String description;
    private String keyInged;
    private Double price;
    private String availableTime;
    private String url;

    @Enumerated(EnumType.STRING)
    private Category category;

    @Enumerated(EnumType.STRING)
    private DietaryType dietaryType;

    @Enumerated(EnumType.STRING)
    private TasteInfo tasteinfo;

    private Boolean available = true;
    private String nutrionalInfo;

    // No-arg constructor
    public MenuResponse() {
    }

    // All-arg constructor
    public MenuResponse(int id, String name, String description, String keyInged, Double price,
                        String availableTime, String url, Category category, DietaryType dietaryType,
                        TasteInfo tasteinfo, Boolean available, String nutrionalInfo) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.keyInged = keyInged;
        this.price = price;
        this.availableTime = availableTime;
        this.url = url;
        this.category = category;
        this.dietaryType = dietaryType;
        this.tasteinfo = tasteinfo;
        this.available = available;
        this.nutrionalInfo = nutrionalInfo;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getKeyInged() {
        return keyInged;
    }

    public void setKeyInged(String keyInged) {
        this.keyInged = keyInged;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getAvailableTime() {
        return availableTime;
    }

    public void setAvailableTime(String availableTime) {
        this.availableTime = availableTime;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public DietaryType getDietaryType() {
        return dietaryType;
    }

    public void setDietaryType(DietaryType dietaryType) {
        this.dietaryType = dietaryType;
    }

    public TasteInfo getTasteinfo() {
        return tasteinfo;
    }

    public void setTasteinfo(TasteInfo tasteinfo) {
        this.tasteinfo = tasteinfo;
    }

    public Boolean getAvailable() {
        return available;
    }

    public void setAvailable(Boolean available) {
        this.available = available;
    }

    public String getNutrionalInfo() {
        return nutrionalInfo;
    }

    public void setNutrionalInfo(String nutrionalInfo) {
        this.nutrionalInfo = nutrionalInfo;
    }
}
