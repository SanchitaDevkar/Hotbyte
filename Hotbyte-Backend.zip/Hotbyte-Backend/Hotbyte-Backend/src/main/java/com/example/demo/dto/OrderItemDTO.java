package com.example.demo.dto;

public class OrderItemDTO {
    private String menuName;
    private int quantity;
    private double price;

    // No-arg constructor
    public OrderItemDTO() {
    }

    // All-arg constructor
    public OrderItemDTO(String menuName, int quantity, double price) {
        this.menuName = menuName;
        this.quantity = quantity;
        this.price = price;
    }

    // Getters and Setters

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
