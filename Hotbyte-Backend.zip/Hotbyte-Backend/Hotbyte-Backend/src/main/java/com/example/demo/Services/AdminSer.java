package com.example.demo.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.Exceptions.MenuNotFound;
import com.example.demo.Exceptions.RestaurantNotFound;
import com.example.demo.Exceptions.UserNotFoundException;
import com.example.demo.Model.Cart;
import com.example.demo.Model.Menu;
import com.example.demo.Model.OrderItem;
import com.example.demo.Model.Orders;
import com.example.demo.Model.Restaurant;
import com.example.demo.Model.User;
import com.example.demo.Repository.CartItemRepo;
import com.example.demo.Repository.CartRepo;
import com.example.demo.Repository.MenuRepo;
import com.example.demo.Repository.OrderItemRepo;
import com.example.demo.Repository.OrdersRepo;
import com.example.demo.Repository.RestaurantRepo;
import com.example.demo.Repository.UserRepo;
import com.example.demo.Security.JwtUtil;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;

@Service
public class AdminSer {
	
	@Autowired
	private UserRepo userrepo;
	@Autowired
	private MenuRepo menurepo;
	@Autowired
	private OrdersRepo ordersrepo;
	@Autowired
	private CartRepo cartrepo;
	@Autowired
	private JwtUtil jwtutil;
	@Autowired
	private RestaurantRepo resrepo;
	@Autowired
	private CartItemRepo cartitemrepo;
	@Autowired
	private OrderItemRepo orderitemrepo;
	@Autowired
	private PasswordEncoder passwordencoder;
		//adduser
		public String addUser(User user1) {
			User user=new User();
			user.setName(user1.getName());
			user.setEmail(user1.getEmail());
			user.setPassword(passwordencoder.encode(user1.getPassword()));
			user.setRole("USER");
			user.setContact(user1.getContact());
			userrepo.save(user);
			return "User registered successfully";
		}
		//addrestaurant
		public String addRestaurant(Restaurant resta) {
			Restaurant res=new Restaurant();
			res.setName(resta.getName());
			res.setEmail(resta.getEmail());
			res.setPassword(passwordencoder.encode(resta.getPassword()));
			res.setRole("RESTAURANT");
			res.setContact(resta.getContact());
			resrepo.save(res);
			return"Restaurant registered successfully";
		}
		//getuserbyid
		public User getuserbyid(int userId) {
			return userrepo.findById(userId)
					.orElseThrow(()->new UserNotFoundException("User wit Id "+userId+ " not found"));
		}
		//getrestaurantbyid
		public Restaurant getbyresid(int resId) {
			return resrepo.findById(resId).orElseThrow(()->new RestaurantNotFound("Restaurabt Not found"));
		}
		
		
		//addMenu
		public Menu AddMenu(int resId,Menu menu) {
			Restaurant restaurant=resrepo.findById(resId)
					.orElseThrow(()->new RestaurantNotFound("restaurant with ID"+resId+"Is not found"));
			menu.setRestaurant(restaurant);
			return menurepo.save(menu);
		}
		//updateMenu
		@Transactional
		public Menu UpdateMenu(int menuid,Menu updatedMenu) {

			Menu existingMenu=menurepo.findById(menuid)
					.orElseThrow(()->new MenuNotFound("Menu with Id"+menuid+"Not Found"));
		
			
				existingMenu.setName(updatedMenu.getName());
				existingMenu.setDescription(updatedMenu.getDescription());
				existingMenu.setKeyInged(updatedMenu.getKeyInged());
				existingMenu.setCategory(updatedMenu.getCategory());
				existingMenu.setPrice(updatedMenu.getPrice());
				existingMenu.setAvailableTime(updatedMenu.getAvailableTime());
				existingMenu.setUrl(updatedMenu.getUrl());
				existingMenu.setDietaryType(updatedMenu.getDietaryType());
				existingMenu.setTasteinfo(updatedMenu.getTasteinfo());
				existingMenu.setNutrionalInfo(updatedMenu.getNutrionalInfo());
				existingMenu.setAvailable(updatedMenu.getAvailable());
			
			return menurepo.save(existingMenu);
			
		}
		
		//deletemenu
		@Transactional
		public String DeleteById(int menuId) {
		    Menu menu = menurepo.findById(menuId)
		            .orElseThrow(() -> new MenuNotFound("Menu with ID " + menuId + " not found"));
		    orderitemrepo.deleteByMenuId(menuId);
		    int restaurantId = menu.getRestaurant().getId();

		    List<Orders> orders = ordersrepo.findAllByRestaurantId(restaurantId);
		    for (Orders order : orders) {
		        if (orderitemrepo.countByOrdersId(order.getId()) == 0) {
		            ordersrepo.delete(order);
		        }
		    }

		    menurepo.delete(menu);

		    return "Menu and all related order items (and empty orders) deleted successfully.";
		}

		
		//deleteuser
		@Transactional
		public String DeleteUser(int userId) {
		    User user = userrepo.findById(userId)
		        .orElseThrow(() -> new UserNotFoundException("User not found"));
		    cartrepo.findByUserId(userId).ifPresent(cartrepo::delete);
		   
		    List<Orders> orders = ordersrepo.findByUserId(userId);

		    for (Orders order : orders) {
		        orderitemrepo.deleteByOrdersId(order.getId());
		    }

		    ordersrepo.deleteAll(orders);

		    userrepo.delete(user);

		    return "User deleted successfully";
		}
		//DeleteRestaurant
		@Transactional
		public String deleteRestaurant(int restaurantId) {
		    Restaurant restaurant = resrepo.findById(restaurantId)
		        .orElseThrow(() -> new RestaurantNotFound("Restaurant not found"));

		    
		    List<Orders> orders = ordersrepo.findAllByRestaurantId(restaurantId);
		    for (Orders order : orders) {
		        orderitemrepo.deleteByOrdersId(order.getId()); 
		    }

		    
		    ordersrepo.deleteAll(orders);
		    List<Menu> menus = menurepo.findAllByRestaurantId(restaurantId);
		    for (Menu menu : menus) {
		        orderitemrepo.deleteByMenuId(menu.getId());  
		    }
		    
		    menurepo.deleteAll(menus);
	
		    resrepo.delete(restaurant);

		    return "Restaurant and all related records deleted.";
		}


		 
		//ViewAll Users
		public List<User> viewAllUsers() {
		    return userrepo.findAll();
		}
		//ViewAll Restaurant
		public List<Restaurant> viewAllRestaurants() {
		    return resrepo.findAll();
		}
		//getallbyrestaurantid
		public List<Menu> getallmenubyresid(int resId){
			return menurepo.findAllByRestaurantId(resId);
		}
		//getmenubyid
		public Menu getallmenubyid(int menuId){
			return menurepo.findById(menuId)
					.orElseThrow(()->new MenuNotFound("Menu not found"));
		}
	

}
