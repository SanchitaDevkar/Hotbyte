package com.example.demo.Services;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.Exceptions.MenuNotFound;
import com.example.demo.Exceptions.OrdersNotFound;
import com.example.demo.Exceptions.RestaurantNotFound;
import com.example.demo.Model.Menu;
import com.example.demo.Model.Orders;
import com.example.demo.Model.Restaurant;
import com.example.demo.Repository.CartItemRepo;
import com.example.demo.Repository.MenuRepo;
import com.example.demo.Repository.OrdersRepo;
import com.example.demo.Repository.RestaurantRepo;
import com.example.demo.Security.JwtUtil;
import com.example.demo.dto.MenuResponse;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;



@Service
public class RestaurantServ {
	
	private static final Logger log = LoggerFactory.getLogger(RestaurantServ.class);
	
	@Autowired
	private RestaurantRepo resRepo;
	@Autowired
	private MenuRepo menuRepo;
	@Autowired
	private OrdersRepo ordersRepo;
	@Autowired
	private CartItemRepo orderitemrepo;
	@Autowired
	private JwtUtil jwtutil;
	@Autowired
	private PasswordEncoder passwordencoder;
	
	
	private int getRestaurantIdFromRequest(HttpServletRequest request) {
		String authHeader=request.getHeader("Authorization");
		if(authHeader!=null&&authHeader.startsWith("Bearer ")) {
			String token=authHeader.substring(7);
			return jwtutil.extractId(token);
		}
		throw new RuntimeException("Authorization header is missing or invalid");
		
		
	}
	
	
	public Restaurant updateProfile(HttpServletRequest request,Restaurant updatedrestaurant) {
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant=resRepo.findById(resId)
				.orElseThrow(()-> new RestaurantNotFound("Restaurant not found with Id") );
		restaurant.setName(updatedrestaurant.getName());
		restaurant.setLocation(updatedrestaurant.getLocation());
		restaurant.setContact(updatedrestaurant.getContact());
		restaurant.setEmail(updatedrestaurant.getEmail());
		restaurant.setPassword(passwordencoder.encode(updatedrestaurant.getPassword()));
		return resRepo.save(restaurant);
		
	}
	
	public Restaurant getprofileRes(HttpServletRequest request) {
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant=resRepo.findById(resId)
				.orElseThrow(()-> new RestaurantNotFound("Restaurant not found with Id") );
		return restaurant;
		
	}
	
	
	@Transactional
	public Menu AddMenu(HttpServletRequest request,Menu menu) {
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant=resRepo.findById(resId)
				.orElseThrow(()->new RestaurantNotFound("restaurant with ID"+resId+"Is not found"));
		menu.setRestaurant(restaurant);
		return menuRepo.save(menu);
		
		
	}
	@Transactional
	public Menu UpdateMenu(HttpServletRequest request,int menuid,Menu updatedMenu) {
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant =resRepo.findById(resId)
				.orElseThrow(()->new RestaurantNotFound("restaurant with ID"+resId+"Is not found"));
		Menu existingMenu=menuRepo.findById(menuid)
				.orElseThrow(()->new MenuNotFound("Menu with Id"+menuid+"Not Found"));
		if(existingMenu.getRestaurant().getId()!=restaurant.getId()) {
			throw new RuntimeException("Menu is not found in the restaurant");
		}
		
			existingMenu.setName(updatedMenu.getName());
			existingMenu.setDescription(updatedMenu.getDescription());
			existingMenu.setKeyInged(updatedMenu.getKeyInged());
			existingMenu.setCategory(updatedMenu.getCategory());
			existingMenu.setPrice(updatedMenu.getPrice());
			existingMenu.setAvailableTime(updatedMenu.getAvailableTime());
			existingMenu.setUrl(updatedMenu.getUrl());
			existingMenu.setDietaryType(updatedMenu.getDietaryType());
			existingMenu.setTasteinfo(updatedMenu.getTasteinfo());
			existingMenu.setNutrionalInfo(updatedMenu.getNutrionalInfo());
			existingMenu.setAvailable(updatedMenu.getAvailable());
		
		return menuRepo.save(existingMenu);
		
	}
	@Transactional
	public String DeleteById(HttpServletRequest request, int menuId) {
	    int restaurantId = getRestaurantIdFromRequest(request);

	    Restaurant restaurant = resRepo.findById(restaurantId)
	            .orElseThrow(() -> new RestaurantNotFound("Restaurant with ID " + restaurantId + " not found"));

	    Menu menu = menuRepo.findById(menuId)
	            .orElseThrow(() -> new MenuNotFound("Menu with ID " + menuId + " not found"));

	    if (menu.getRestaurant().getId() != restaurant.getId()) {
	        throw new MenuNotFound("Menu does not belong to this restaurant.");
	    }
	    orderitemrepo.deleteByMenuId(menuId);

	    List<Orders> orders = ordersRepo.findAllByRestaurantId(restaurantId);
	    for (Orders order : orders) {
	        if (orderitemrepo.countByOrdersId(order.getId()) == 0) {
	            ordersRepo.delete(order);
	        }
	    }
	    menuRepo.delete(menu);

	    return "Menu and all related items deleted successfully.";
	}


	@Transactional
	public String UpdateOutOfStock(HttpServletRequest request,int menuid) {
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant = resRepo.findById(resId)
				.orElseThrow(()->new RestaurantNotFound("restaurant with ID"+resId+"Is not found"));
		Menu menu=menuRepo.findById(menuid)
				.orElseThrow(()->new MenuNotFound("Menu with Id"+menuid+"Not Found"));
		if(menu.getRestaurant().getId()!=restaurant.getId()) {
			throw new MenuNotFound("Menu Not found in the restaurant to delete");
			
		}
		menu.setAvailable(false);
		menuRepo.save(menu);
		return"Menu is marked as OutOfStock";
	}
	@Transactional
	public String UpdateInStock(HttpServletRequest request,int menuid) {
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant = resRepo.findById(resId)
				.orElseThrow(()->new RestaurantNotFound("restaurant with ID"+resId+"Is not found"));
		Menu menu=menuRepo.findById(menuid)
				.orElseThrow(()->new MenuNotFound("Menu with Id"+menuid+"Not Found"));
		if(menu.getRestaurant().getId()!=restaurant.getId()) {
			throw new MenuNotFound("Menu Not found in the restaurant to delete");
			
		}
		if(Boolean.TRUE.equals(menu.getAvailable())) {
			throw new RuntimeException("the menu is already available in stock");
		}
		menu.setAvailable(true);
		menuRepo.save(menu);
		return"Menu is marked as InStock";
	}
	public List<Menu> viewAllMenu(HttpServletRequest request){
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant = resRepo.findById(resId)
				.orElseThrow(()->new RestaurantNotFound("restaurant with ID"+resId+"Is not found"));
				return menuRepo.findAllByRestaurantId(resId);
	}
	
	
	public List<Menu> viewAllMenuByAvailableTrue(HttpServletRequest request){
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant=resRepo.findById(resId)
				.orElseThrow(()->new RestaurantNotFound("restaurant with ID"+resId+"Is not found"));
		return menuRepo.findAllByRestaurantIdAndAvailable(resId,true);
	}
	
	
	public List<Menu> viewAllMenuByAvailablefalse(HttpServletRequest request){
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant=resRepo.findById(resId)
				.orElseThrow(()->new RestaurantNotFound("restaurant with ID"+resId+"Is not found"));
		return menuRepo.findAllByRestaurantIdAndAvailable(resId,false);
	}
	
	
	public List<Orders> ViewAllOrder(HttpServletRequest request){
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant = resRepo.findById(resId)
				.orElseThrow(()->new RestaurantNotFound("restaurant with ID"+resId+"Is not found"));
		return ordersRepo.findAllByRestaurantId(resId);
	}
	
	
	
	public List<Orders> HistoryOfOrder (HttpServletRequest request){
		int resId=getRestaurantIdFromRequest(request);
		return ordersRepo.findAllByRestaurantIdAndStatus(resId,"DELIVERED");
	}
	
	public List<Orders> ViewPendingOrder(HttpServletRequest request){
		int resId=getRestaurantIdFromRequest(request);
		return ordersRepo.findAllByRestaurantIdAndStatus(resId, "PENDING");
	}
	public List<Orders> ViewProcessingOrder(HttpServletRequest request){
		int resId=getRestaurantIdFromRequest(request);
		return ordersRepo.findAllByRestaurantIdAndStatus(resId, "PROCESSING");
	}
	
	public List<Orders> Viewoutfordelivery(HttpServletRequest request){
		int resId=getRestaurantIdFromRequest(request);
		return ordersRepo.findAllByRestaurantIdAndStatus(resId, "OUT FOR DELIVERY");
	}
	
	@Transactional
	public String setOrderAsProcessing(HttpServletRequest request,int ordersId) {
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant =resRepo.findById(resId)
				.orElseThrow(()->new RestaurantNotFound("restaurant with ID"+resId+"Is not found"));
		Orders orders=ordersRepo.findById(ordersId)
				.orElseThrow(()->new OrdersNotFound("Orders with ID"+ordersId+"Is not found"));
		if(orders.getRestaurant().getId()==restaurant.getId()) {
			if(orders.getStatus().equalsIgnoreCase("PENDING")) {
				orders.setStatus("PROCESSING");
				ordersRepo.save(orders);
			}
			else {
				throw new RuntimeException("The Order in the status"+orders.getStatus());
			}
		}
		return "Status has been updated To Processing";
	}
	
	public String setOrderAsOutforDelivery(HttpServletRequest request,int orderid) {
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant =resRepo.findById(resId)
				.orElseThrow(()->new RestaurantNotFound("restaurant with ID"+resId+"Is not found"));
		Orders orders=ordersRepo.findById(orderid)
				.orElseThrow(()->new OrdersNotFound("Orders with ID"+orderid+"Is not found"));
		if(orders.getRestaurant().getId()==restaurant.getId()) {
			if(orders.getStatus().equalsIgnoreCase("PROCESSING")) {
				orders.setStatus("OUT FOR DELIVERY");
				ordersRepo.save(orders);
			}
			else {
				throw new RuntimeException("The Order in the status"+orders.getStatus()+"Cannot be changed");
			}
		}
		return "Status has been updated To outfordelievry";
	}
	

	public String setOrderAsCancel(HttpServletRequest request,int orderid) {
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant =resRepo.findById(resId)
				.orElseThrow(()->new RestaurantNotFound("restaurant with ID"+resId+"Is not found"));
		Orders orders=ordersRepo.findById(orderid)
				.orElseThrow(()->new OrdersNotFound("Orders with ID"+orderid+"Is not found"));
		if(orders.getRestaurant().getId()==restaurant.getId()) {
			if(orders.getStatus().equalsIgnoreCase("PENDING")) {
				orders.setStatus("CANCELLED");
				ordersRepo.save(orders);
			}
			else {
				throw new RuntimeException("The Order in the status"+orders.getStatus()+"Cannot be changed");
			}
		}
		return "Status has been updated To Cancelled";
	}
	
	
	public String setOrderAsDelivery(HttpServletRequest request,int orderid) {
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant =resRepo.findById(resId)
				.orElseThrow(()->new RestaurantNotFound("restaurant with ID"+resId+"Is not found"));
		Orders orders=ordersRepo.findById(orderid)
				.orElseThrow(()->new OrdersNotFound("Orders with ID"+orderid+"Is not found"));
		if(orders.getRestaurant().getId()==restaurant.getId()) {
			if(orders.getStatus().equalsIgnoreCase("OUT FOR DELIVERY")) {
				orders.setStatus("DELIVERED");
				ordersRepo.save(orders);
			}
			else {
				throw new RuntimeException("The Order in the status"+orders.getStatus()+"Cannot be changed");
			}
		}
		return "Status has been updated To DELIVERED";
	}
	
	public Optional<Menu> getmenubyId(HttpServletRequest request,int menuId){
		int resId=getRestaurantIdFromRequest(request);
		Restaurant restaurant=resRepo.findById(resId)
				.orElseThrow(()->new RestaurantNotFound("Rsataurant not found"));
	
		Menu menu=menuRepo.findById(menuId)
				.orElseThrow(()->new MenuNotFound("Menu with Id not found"));
	return menuRepo.findById(menuId);
		
	}
	
	
	
}


