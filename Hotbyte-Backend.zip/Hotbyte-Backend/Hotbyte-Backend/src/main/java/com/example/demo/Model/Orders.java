package com.example.demo.Model;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Orders {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    private User user;

    @ManyToOne
    private Restaurant restaurant;

    @OneToMany(mappedBy = "orders", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<OrderItem> orderitem;

    private String shippingAddress;
    private String paymentMethod;
    private Double totalAmount;
    private LocalDateTime orderTime;
    private String status = "Pending";

    // No-arg constructor
    public Orders() {
    }

    // All-arg constructor
    public Orders(int id, User user, Restaurant restaurant, List<OrderItem> orderitem,
                  String shippingAddress, String paymentMethod, Double totalAmount,
                  LocalDateTime orderTime, String status) {
        this.id = id;
        this.user = user;
        this.restaurant = restaurant;
        this.orderitem = orderitem;
        this.shippingAddress = shippingAddress;
        this.paymentMethod = paymentMethod;
        this.totalAmount = totalAmount;
        this.orderTime = orderTime;
        this.status = status;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public List<OrderItem> getOrderitem() {
        return orderitem;
    }

    public void setOrderitem(List<OrderItem> orderitem) {
        this.orderitem = orderitem;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(String shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public LocalDateTime getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(LocalDateTime orderTime) {
        this.orderTime = orderTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // equals() and hashCode()

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Orders)) return false;
        Orders orders = (Orders) o;
        return id == orders.id &&
               Objects.equals(user, orders.user) &&
               Objects.equals(restaurant, orders.restaurant) &&
               Objects.equals(orderitem, orders.orderitem) &&
               Objects.equals(shippingAddress, orders.shippingAddress) &&
               Objects.equals(paymentMethod, orders.paymentMethod) &&
               Objects.equals(totalAmount, orders.totalAmount) &&
               Objects.equals(orderTime, orders.orderTime) &&
               Objects.equals(status, orders.status);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, user, restaurant, orderitem, shippingAddress, paymentMethod,
                            totalAmount, orderTime, status);
    }
}
