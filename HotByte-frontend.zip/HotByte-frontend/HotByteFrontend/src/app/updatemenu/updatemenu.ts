import { Component } from '@angular/core';
import { Restaurantservice } from '../restaurantservice';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-updatemenu',
  standalone: false,
  templateUrl: './updatemenu.html',
  styleUrl: './updatemenu.css'
})
export class Updatemenu {
  successful:any;
  upDatemenuForm!:FormGroup;
  id!:any;
  constructor(private resservice:Restaurantservice,private activeRoute:ActivatedRoute,
    private fb:FormBuilder,private router:Router
  ){

  }

  ngOnInit(){
    this.id=this.activeRoute.snapshot.paramMap.get('id');
    this.getmenubyid();
    this.upDatemenuForm=this.fb.group({
     name:[null,[Validators.required]],
     description:[null,[Validators.required]],
     keyInged:[null,[Validators.required]],
      price:[null,[Validators.required]],
      availableTime:[null,[Validators.required]],
      url:[null,[Validators.required]],
      category:[null,[Validators.required]],
      dietaryType:[null,[Validators.required]],
      tasteinfo:[null,[Validators.required]],
      nutrionalInfo:[null,[Validators.required]]
    })

  }


  getmenubyid(){
    this.resservice.getmenubyid(this.id).subscribe({
      next:res=>{
        console.log(res);
        this.upDatemenuForm.patchValue(res);
      }
    })
  }

  updateMenu(){
    this,this.resservice.updatemenu(this.id,this.upDatemenuForm.value).subscribe({
      next:res=>{
        console.log(res);
        this.router.navigateByUrl('/getallmenu');
        successful:"Menu Updated Successfully";


      }
    })
  }

}
