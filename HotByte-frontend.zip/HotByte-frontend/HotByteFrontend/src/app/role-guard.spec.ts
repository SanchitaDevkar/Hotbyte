import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RoleGuard } from './role-guard';
import { ActivatedRouteSnapshot } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

describe('RoleGuard', () => {
  let guard: RoleGuard;
  let router: Router;

  const createRouteSnapshot = (expectedRole: string): ActivatedRouteSnapshot => {
    const snapshot = new ActivatedRouteSnapshot();
    snapshot.data = { expectedRole };
    return snapshot;
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [RoleGuard]
    });

    guard = TestBed.inject(RoleGuard);
    router = TestBed.inject(Router);
    spyOn(router, 'navigate'); // prevent actual routing
    localStorage.clear();
  });

  it('should return false and redirect to login if no token', () => {
    const route = createRouteSnapshot('USER');
    const result = guard.canActivate(route);
    expect(result).toBeFalse();
    expect(router.navigate).toHaveBeenCalledWith(['/login']);
  });

  it('should return true if token exists and role matches', () => {
    const payload = { role: 'USER' };
    const token = createToken(payload);
    localStorage.setItem('jwtToken', token);

    const route = createRouteSnapshot('USER');
    const result = guard.canActivate(route);

    expect(result).toBeTrue();
    expect(router.navigate).not.toHaveBeenCalled();
  });

  it('should return false and redirect if roles do not match', () => {
    const payload = { role: 'ADMIN' };
    const token = createToken(payload);
    localStorage.setItem('jwtToken', token);

    const route = createRouteSnapshot('USER');
    const result = guard.canActivate(route);

    expect(result).toBeFalse();
    expect(router.navigate).toHaveBeenCalledWith(['/login']);
  });

  it('should return false and redirect if token is invalid', () => {
    localStorage.setItem('jwtToken', 'invalid.token.value');

    const route = createRouteSnapshot('USER');
    const result = guard.canActivate(route);

    expect(result).toBeFalse();
    expect(router.navigate).toHaveBeenCalledWith(['/login']);
  });

  // Helper to create a fake JWT
  function createToken(payload: any): string {
    const header = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
    const body = btoa(JSON.stringify(payload));
    return `${header}.${body}.signature`;
  }
});
