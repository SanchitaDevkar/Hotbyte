import { TestBed } from '@angular/core/testing';

import { Restaurantservice } from './restaurantservice';

describe('Restaurantservice', () => {
  let service: Restaurantservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Restaurantservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
