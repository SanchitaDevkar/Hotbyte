import { Component, OnInit } from '@angular/core';
import { Userservice } from '../userservice';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-summaryorder',
  standalone: false,
  templateUrl: './summaryorder.html',
  styleUrl: './summaryorder.css'
})
export class Summaryorder implements OnInit {

  id:any;
  orderSummary:any;
  constructor(private userservice:Userservice,private activeroute:ActivatedRoute,private router1:Router){

  }

  ngOnInit(){

    this.id=this.activeroute.snapshot.paramMap.get('id');
    this.viewsummary();
  }
  viewsummary(){
    return this.userservice.ordersummary(this.id).subscribe({
      next:res=>{
        console.log(res);
        this.orderSummary=res;
      }
    })
  }
    logout(): void {
  console.log('Logging out...');


  localStorage.removeItem('auth-key');
  localStorage.removeItem('jwtToken');

  localStorage.removeItem('role');
  localStorage.removeItem('user');


  this.router1.navigate(['/login']);
}

}
