import { Component, OnInit } from '@angular/core';
import { Userservice } from '../userservice';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { Route, Router } from '@angular/router';
@Component({
  selector: 'app-userdashboard',
  standalone: false,
  templateUrl: './userdashboard.html',
  styleUrl: './userdashboard.css'
})
export class Userdashboard implements OnInit {
  menuForm!: FormGroup;
  menu: any = [];
  menuname: string = '';
  errMessage = '';

  constructor(private userser: Userservice, private fb: FormBuilder,private router:Router) {}

  ngOnInit() {
    this.getallmenu();

    this.menuForm = this.fb.group({
      category: [''],
      dietary: [''],
      priceRange: ['']
    });
  }
  

  getallmenu() {
    this.userser.getallmenu().subscribe({
      next: res => {
        this.menu = res;
        this.errMessage = '';
      },
      error: err => {
        console.error('Error fetching all menu:', err);
      }
    });
  }

  getmenubyname(menuname: string) {
    this.userser.getmenubyname(menuname).subscribe({
      next: res => {
        this.menu = res;
        this.errMessage = '';

        if (!this.menu || this.menu.length === 0) {
          this.errMessage = 'Match Not Found';
          this.getallmenu(); // Optionally fallback to full list
        }
      },
      error: err => {
        console.error('Error searching menu:', err);
      }
    });
  }

  applyFilters() {
    let { category, dietary, priceRange } = this.menuForm.value;

    // Default values for optional filters
    category = category?.trim() || '';
    dietary = dietary?.trim() || '';

    let minPrice = 0;
    let maxPrice = 100000;

    if (priceRange) {
      const [min, max] = priceRange.split('-').map(Number);
      minPrice = min;
      maxPrice = max;
    }

   this.userser.getfiltermenu(category, dietary, minPrice, maxPrice).subscribe({
  next: res => {
    const filteredMenu = res as any[];  // 👈 Tells TypeScript this is an array
    this.menu = filteredMenu;
    this.errMessage = (!filteredMenu || filteredMenu.length === 0)
      ? 'No matching menu found.'
      : '';
  },
  error: err => {
    console.error('Error applying filters:', err);
  }
});

  }

  resetFilters() {
    this.menuForm.reset();
    this.errMessage = '';
    this.getallmenu();
  }

   logout(): void {
  console.log('Logging out...');


  localStorage.removeItem('auth-key');
  localStorage.removeItem('jwtToken');


  localStorage.removeItem('role');
  localStorage.removeItem('user');


  this.router.navigate(['/login']);
}


 
}
