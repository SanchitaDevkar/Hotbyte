import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { Register } from './register/register';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { Admindashboard } from './admindashboard/admindashboard';
import { Restaurantdashboard } from './restaurantdashboard/restaurantdashboard';
import { Login } from './login/login';
import  { JwtInterceptor } from './jwt-interceptor';
import { MenuManagement } from './menu-management/menu-management';
import { Addmenu } from './addmenu/addmenu';
import { Getallmenu } from './getallmenu/getallmenu';
import { Updatemenu } from './updatemenu/updatemenu';
import { Instock } from './instock/instock';
import { Outstock } from './outstock/outstock';
import { Userdashboard } from './usercomponents/userdashboard/userdashboard';
import { Setprofile } from './setprofile/setprofile';
import { Getmenuuser } from './usercomponents/getmenuuser/getmenuuser';
import { Cart } from './usercomponents/cart/cart';
import { Checkout } from './usercomponents/checkout/checkout';
import { Summaryorder } from './usercomponents/summaryorder/summaryorder';
import { Orderview } from './usercomponents/orderview/orderview';
import { Ordermanagement } from './restaurantcomponents/ordermanagement/ordermanagement';
import { Pendingorder } from './restaurantcomponents/pendingorder/pendingorder';
import { Processingorder } from './restaurantcomponents/processingorder/processingorder';
import { Outfordelivery } from './restaurantcomponents/outfordelivery/outfordelivery';
import { Orderhistory } from './restaurantcomponents/orderhistory/orderhistory';
import { Navorder } from './restaurantcomponents/navorder/navorder';
import { Usermanagement } from './admincomponents/usermanagement/usermanagement';
import { UserUi } from './admincomponents/user-ui/user-ui';
import { Adduser } from './admincomponents/adduser/adduser';
import { Deleteuser } from './admincomponents/deleteuser/deleteuser';
import { RestaurantUi } from './admincomponents/restaurant-ui/restaurant-ui';
import { Addrestaurant } from './admincomponents/addrestaurant/addrestaurant';
import { Deleterestaurant } from './admincomponents/deleterestaurant/deleterestaurant';
import { Adminmenu } from './admincomponents/adminmenu/adminmenu';
import { Viewrestaurant } from './admincomponents/viewrestaurant/viewrestaurant';
import { Adminviewmenu } from './admincomponents/adminviewmenu/adminviewmenu';
import { Adminupdatemenu } from './admincomponents/adminupdatemenu/adminupdatemenu';





@NgModule({
  declarations: [
    App,
    Register,
    Admindashboard,
    Restaurantdashboard,
    Login,
    MenuManagement,
    Addmenu,
    Getallmenu,
    Updatemenu,
    Instock,
    Outstock,
    Userdashboard,
    Setprofile,
    Getmenuuser,
    Cart,
    Checkout,
    Summaryorder,
    Orderview,
    Ordermanagement,
    Pendingorder,
    Processingorder,
    Outfordelivery,
    Orderhistory,
    Navorder,
    Usermanagement,
    UserUi,
    Adduser,
    Deleteuser,
    RestaurantUi,
    Addrestaurant,
    Deleterestaurant,
    Adminmenu,
    Viewrestaurant,
    Adminviewmenu,
    Adminupdatemenu,
  

  
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: JwtInterceptor,
      multi: true
    }
  ],
  bootstrap: [App]
})
export class AppModule { }
