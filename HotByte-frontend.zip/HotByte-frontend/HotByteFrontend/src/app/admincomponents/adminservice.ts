import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
const baseUrl="http://localhost:9988/api/admin";
@Injectable({
  providedIn: 'root'
})
export class Adminservice {

  constructor(private http:HttpClient) { }

 adduser1(user1: any) {
  return this.http.post(`${baseUrl}/add-user`, user1, {
    responseType: 'text' as const
  });
}

getalluser(){
  return this.http.get(`${baseUrl}/users`);
}
Deleteuser(id:number){
  return this.http.delete(`${baseUrl}/delete-user/${id}`,{
    responseType:'text'
  });
}

addrestaurant(restaurant:any){
  return this.http.post(`${baseUrl}/add-restaurant`,restaurant,{
    responseType:'text'
  });
}
getallrestaurant(){
  return this.http.get(`${baseUrl}/restaurants`);
}
deleterestaurantbyid(id:number){
  return this.http.delete(`${baseUrl}/delete-restaurant/${id}`,{
    responseType:'text'
  });
}
getmenubyresid(id:number){
  return this.http.get(`${baseUrl}/restaurant/getmenu/${id}`);
}
getmenubyid(id:any){
  return this.http.get(`${baseUrl}/menu/${id}`);
}
updatemenubyid(id:any,menu:any):Observable<any>{
  return this.http.put(`${baseUrl}/update-menu/${id}`,menu)
}
deletemenubyid(id:any){
  return this.http.delete(`${baseUrl}/delete-menu/${id}`,{
    responseType:'text'
  });
}

  }

