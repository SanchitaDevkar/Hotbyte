import { Component } from '@angular/core';

@Component({
  selector: 'app-restaurant-ui',
  standalone: false,
  templateUrl: './restaurant-ui.html',
  styleUrl: './restaurant-ui.css'
})
export class RestaurantUi {

}
