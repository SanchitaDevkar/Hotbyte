import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserUi } from './user-ui';

describe('UserUi', () => {
  let component: UserUi;
  let fixture: ComponentFixture<UserUi>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UserUi]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserUi);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
