import { Component, OnInit } from '@angular/core';
import { Adminservice } from '../adminservice';

@Component({
  selector: 'app-viewrestaurant',
  standalone: false,
  templateUrl: './viewrestaurant.html',
  styleUrl: './viewrestaurant.css'
})
export class Viewrestaurant implements OnInit {
  restuarnts:any;
  constructor(private adminser:Adminservice){

  }
 ngOnInit(): void {
  this.getallrestaurant();
     
 }

 getallrestaurant(){
  return this.adminser.getallrestaurant().subscribe({
    next:res=>{
      console.log(res);
      this.restuarnts=res;
    }
  })
 }

}
