import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Adminupdatemenu } from './adminupdatemenu';

describe('Adminupdatemenu', () => {
  let component: Adminupdatemenu;
  let fixture: ComponentFixture<Adminupdatemenu>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Adminupdatemenu]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Adminupdatemenu);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
