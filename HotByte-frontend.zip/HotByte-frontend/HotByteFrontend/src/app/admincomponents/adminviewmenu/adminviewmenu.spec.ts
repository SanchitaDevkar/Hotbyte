import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Adminviewmenu } from './adminviewmenu';

describe('Adminviewmenu', () => {
  let component: Adminviewmenu;
  let fixture: ComponentFixture<Adminviewmenu>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Adminviewmenu]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Adminviewmenu);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
