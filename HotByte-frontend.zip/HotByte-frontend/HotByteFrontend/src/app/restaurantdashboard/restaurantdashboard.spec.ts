import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Restaurantdashboard } from './restaurantdashboard';

describe('Restaurantdashboard', () => {
  let component: Restaurantdashboard;
  let fixture: ComponentFixture<Restaurantdashboard>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Restaurantdashboard]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Restaurantdashboard);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
