import { Component, OnInit } from '@angular/core';
import { Restaurantservice } from '../../restaurantservice';

@Component({
  selector: 'app-processingorder',
  standalone: false,
  templateUrl: './processingorder.html',
  styleUrl: './processingorder.css'
})
export class Processingorder implements OnInit{
  processing:any;
  constructor(private resservice:Restaurantservice) {
    
  }
  ngOnInit(): void {
    this.getprocessing();
      
  }


  getprocessing(){
    return this.resservice.viewprocessingorder().subscribe({
      next:res=>{
        console.log(res);
        this.processing=res;
      }
    })
  }

  outfordeliver(id:number){
    return this.resservice.setoutfordelivery(id).subscribe({
      next:res=>{
        console.log(res);
        this.getprocessing();
      }
    })
  }



}
