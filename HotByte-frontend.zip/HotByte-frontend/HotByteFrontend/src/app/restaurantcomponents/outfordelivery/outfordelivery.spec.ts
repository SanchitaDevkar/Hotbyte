import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Outfordelivery } from './outfordelivery';

describe('Outfordelivery', () => {
  let component: Outfordelivery;
  let fixture: ComponentFixture<Outfordelivery>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Outfordelivery]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Outfordelivery);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
