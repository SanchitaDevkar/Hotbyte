import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Navorder } from './navorder';

describe('Navorder', () => {
  let component: Navorder;
  let fixture: ComponentFixture<Navorder>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Navorder]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Navorder);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
