import { Component, OnInit } from '@angular/core';
import { Restaurantservice } from '../../restaurantservice';

@Component({
  selector: 'app-orderhistory',
  standalone: false,
  templateUrl: './orderhistory.html',
  styleUrl: './orderhistory.css'
})
export class Orderhistory implements OnInit {
  history:any;
  constructor(private reservice:Restaurantservice){

  }
  ngOnInit(): void {
    this.viewhistoryall();
      
  }

  viewhistoryall(){
    return this.reservice.viewhistory().subscribe({
      next:res=>{
        console.log(res);
        this.history=res;
      }
    })
  }

}
