import { Component } from '@angular/core';
import { Registerservice } from '../registerservice';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {  Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
  LoginForm!:FormGroup;

  constructor(private loginservice:Registerservice,private fb:FormBuilder,private router:Router){

  }
  ngOnInit(){
    this.LoginForm=this.fb.group({
      email:[null,[Validators.required]],
      password:[null,[Validators.required]]
    })


  }


  LoginUser(){
    
    this.loginservice.loginUser(this.LoginForm.value).subscribe({
      next: (res: any) => {
        const token = typeof res === 'string' ? res : res.token;
        console.log('Token:', token);

        localStorage.setItem('jwtToken', token);

        const payload = JSON.parse(atob(token.split('.')[1]));
        const role = payload.role;
        console.log('User role:', role);

        if (role === 'ADMIN') {
          this.router.navigate(['/admindashboard']);
        } else if (role === 'RESTAURANT') {
          this.router.navigate(['/restaurantdashboard']);
        } else if (role === 'USER') {
          this.router.navigate(['/userdashboard']);
        } else {
          alert('Unknown role');
        }
      },
      error: (err) => {
        console.error('Login error', err);
        alert('Invalid login credentials.');
      }
    });


}



}
