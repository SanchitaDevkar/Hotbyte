import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
const baseUrl='http://localhost:9988/api/restaurant';

@Injectable({
  providedIn: 'root'
})
export class Restaurantservice {

  constructor(private http:HttpClient) { }
   postMenu(menu:any){
    return this.http.post(`${baseUrl}/menu`,menu);
   }
   getallmenu(){
    return this.http.get(`${baseUrl}/menus`);
   }
    getmenubyid(id:any){
    return this.http.get(`${baseUrl}/menu/${id}`);
   }
   updatemenu(id:any,menu:any){
    return this.http.put(`${baseUrl}/menu/${id}`,menu);
   }

   deletebyid(id:any){
    return this.http.delete(`${baseUrl}/menu/${id}`);
   }

   getmenubyavailabilitytrue(){
    return this.http.get(`${baseUrl}/menu/instock`);
   }
   updateMenuAvailablestocktoout(id:any){
    return this.http.put(`${baseUrl}/menu/${id}/out-of-stock`,{},{ responseType: 'text' });
   }
   getbyavailablefalse(){
    return this.http.get(`${baseUrl}/menu/outstock`);
   }
   updateMenubyinstock(id:number){
    return this.http.put(`${baseUrl}/menu/${id}/in-stock`,{},{responseType:'text'})
   }

   setprofile(){
    return this.http.get(`${baseUrl}/restaurant/profile`);
   }
   viewpendingorder(){
    return this.http.get(`${baseUrl}/orders/pending`);
   }
  acceptorders(id: number) {
  return this.http.put(`${baseUrl}/orders/processing/${id}`, null,{
    responseType:'text'
  });
}
viewprocessingorder(){
  return this.http.get(`${baseUrl}/orders/processing`);
}
setoutfordelivery(id:number){
  return this.http.put(`${baseUrl}/orders/${id}/outfordelivery`,null,{
    responseType:'text'
  })
}
viewoutfordelivery(){
  return this.http.get(`${baseUrl}/orders/outfordelivery`);
}
setdelivered(id:number){
  return this.http.put(`${baseUrl}/orders/${id}/delivered`,null,{
    responseType:'text'
  })
}
viewhistory(){
  return this.http.get(`${baseUrl}/orders/history`);
}
setcancelled(id:number){
  return this.http.put(`${baseUrl}/orders/${id}/cancelled`,null,{
    responseType:'text'
  })
}



}
