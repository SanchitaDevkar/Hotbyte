import { Component, OnInit } from '@angular/core';
import { Userservice } from '../userservice';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-getmenuuser',
  standalone: false,
  templateUrl: './getmenuuser.html',
  styleUrl: './getmenuuser.css'
})
export class Getmenuuser implements OnInit {
  id!:any;
  menu:any=[];
  quantity:any=1;
  constructor(private userservice:Userservice,private fb:FormBuilder,private activaterouter:ActivatedRoute,private router1:Router) {

    
  }

  ngOnInit(){
    this.id=this.activaterouter.snapshot.paramMap.get('id');
    this.getmenubyid();


  }
  getmenubyid(){
    return this.userservice.getmenubyid(this.id).subscribe({
      next:res=>{
        console.log(res);
        this.menu=res;
      }
    })

  }
   addtocart() {
    this.userservice.addToCart(this.id, this.quantity).subscribe({
      next: res => {
        console.log(res);
        this.router1.navigateByUrl('/cart');
      }
    });
  }
  logout(): void {
  console.log('Logging out...');


  localStorage.removeItem('auth-key');
  localStorage.removeItem('jwtToken');

  localStorage.removeItem('role');
  localStorage.removeItem('user');


  this.router1.navigate(['/login']);
}



}