import { Component, OnInit } from '@angular/core';
import { Adminservice } from '../adminservice';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-adminviewmenu',
  standalone: false,
  templateUrl: './adminviewmenu.html',
  styleUrl: './adminviewmenu.css'
})
export class Adminviewmenu implements OnInit{
  menu:any;
  id!:any;

  constructor(private adminserv:Adminservice,private activerouter:ActivatedRoute){
  }
  ngOnInit(): void {
    this.id=this.activerouter.snapshot.paramMap.get('id');
    this.getallmenu();
      
  }
  getallmenu(){
    return this.adminserv.getmenubyresid(this.id).subscribe({
      next:res=>{
        console.log(res);
        this.menu=res;
      }
    })

  }
  deletemenubyid(menuid:any){
    return this.adminserv.deletemenubyid(menuid).subscribe({
      next:res=>{
        console.log(res);
        this.getallmenu();

      }
    })
  }

}
