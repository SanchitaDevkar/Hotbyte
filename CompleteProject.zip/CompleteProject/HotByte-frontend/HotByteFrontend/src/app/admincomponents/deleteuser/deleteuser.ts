import { Component, OnInit } from '@angular/core';
import { Adminservice } from '../adminservice';

@Component({
  selector: 'app-deleteuser',
  standalone: false,
  templateUrl: './deleteuser.html',
  styleUrl: './deleteuser.css'
})
export class Deleteuser implements OnInit {
  users!:any;
  constructor(private adminser:Adminservice) {

    
  }
  ngOnInit(): void {
    this.getusers();
      
  }
  getusers(){
    return this.adminser.getalluser().subscribe({
      next:res=>{
        console.log(res)
        this.users=res;
      }

    })
  }

  deleteuserbyid(id:number){
    return this.adminser.Deleteuser(id).subscribe({
      next:res=>{
        console.log(res);
        this.getusers();
      }
    })
  }

}
