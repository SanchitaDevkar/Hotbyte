import { Component } from '@angular/core';
import { Restaurantservice } from '../restaurantservice';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-getallmenu',
  standalone: false,
  templateUrl: './getallmenu.html',
  styleUrl: './getallmenu.css'
})
export class Getallmenu {
menu:any;
  constructor(private resservice:Restaurantservice,private fb:FormBuilder,private router:Router){}


  ngOnInit(): void {
    this.getallmenu();
    
    
  }

  
getallmenu(){
  return this.resservice.getallmenu().subscribe(res=>{
    console.log(res);
    this.menu=res;
   
  })
}

deletebyid(id:any){
  this.resservice.deletebyid(id).subscribe({
    next:res=>{
      console.log(res);
      this.getallmenu();
    }
  })

}



}
