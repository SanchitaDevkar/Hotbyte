import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Instock } from './instock';

describe('Instock', () => {
  let component: Instock;
  let fixture: ComponentFixture<Instock>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Instock]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Instock);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
