package com.example.demo.Model;

import com.example.demo.Model.Enum.Category;
import com.example.demo.Model.Enum.DietaryType;
import com.example.demo.Model.Enum.TasteInfo;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

import java.util.Objects;

@Entity
public class Menu {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;
    private String description;
    private String keyInged;
    private Double price;
    private String availableTime;
    private String url;

    @Enumerated(EnumType.STRING)
    private Category category;

    @Enumerated(EnumType.STRING)
    private DietaryType dietaryType;

    @Enumerated(EnumType.STRING)
    private TasteInfo tasteinfo;

    private Boolean available = true;
    private String nutrionalInfo;

    @ManyToOne
    private Restaurant restaurant;

    // No-arg constructor
    public Menu() {
    }

    // All-arg constructor
    public Menu(int id, String name, String description, String keyInged, Double price, String availableTime,
                String url, Category category, DietaryType dietaryType, TasteInfo tasteinfo, Boolean available,
                String nutrionalInfo, Restaurant restaurant) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.keyInged = keyInged;
        this.price = price;
        this.availableTime = availableTime;
        this.url = url;
        this.category = category;
        this.dietaryType = dietaryType;
        this.tasteinfo = tasteinfo;
        this.available = available;
        this.nutrionalInfo = nutrionalInfo;
        this.restaurant = restaurant;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getKeyInged() {
        return keyInged;
    }

    public void setKeyInged(String keyInged) {
        this.keyInged = keyInged;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getAvailableTime() {
        return availableTime;
    }

    public void setAvailableTime(String availableTime) {
        this.availableTime = availableTime;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public DietaryType getDietaryType() {
        return dietaryType;
    }

    public void setDietaryType(DietaryType dietaryType) {
        this.dietaryType = dietaryType;
    }

    public TasteInfo getTasteinfo() {
        return tasteinfo;
    }

    public void setTasteinfo(TasteInfo tasteinfo) {
        this.tasteinfo = tasteinfo;
    }

    public Boolean getAvailable() {
        return available;
    }

    public void setAvailable(Boolean available) {
        this.available = available;
    }

    public String getNutrionalInfo() {
        return nutrionalInfo;
    }

    public void setNutrionalInfo(String nutrionalInfo) {
        this.nutrionalInfo = nutrionalInfo;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    // equals() and hashCode()

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Menu)) return false;
        Menu menu = (Menu) o;
        return id == menu.id &&
               Objects.equals(name, menu.name) &&
               Objects.equals(description, menu.description) &&
               Objects.equals(keyInged, menu.keyInged) &&
               Objects.equals(price, menu.price) &&
               Objects.equals(availableTime, menu.availableTime) &&
               Objects.equals(url, menu.url) &&
               category == menu.category &&
               dietaryType == menu.dietaryType &&
               tasteinfo == menu.tasteinfo &&
               Objects.equals(available, menu.available) &&
               Objects.equals(nutrionalInfo, menu.nutrionalInfo) &&
               Objects.equals(restaurant, menu.restaurant);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, description, keyInged, price, availableTime, url,
                            category, dietaryType, tasteinfo, available, nutrionalInfo, restaurant);
    }
}
