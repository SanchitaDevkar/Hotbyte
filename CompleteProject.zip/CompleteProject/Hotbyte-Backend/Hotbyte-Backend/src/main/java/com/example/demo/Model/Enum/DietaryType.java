package com.example.demo.Model.Enum;

public enum DietaryType {
	 VEG, NONVEG

}
