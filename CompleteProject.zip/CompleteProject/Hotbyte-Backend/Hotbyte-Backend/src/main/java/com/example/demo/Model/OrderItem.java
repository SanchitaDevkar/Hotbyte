package com.example.demo.Model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

import java.util.Objects;

@Entity
public class OrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    private Menu menu;

    private int quantity;
    private Double price;

    @ManyToOne
    @JsonBackReference
    private Orders orders;

    // No-arg constructor
    public OrderItem() {
    }

    // All-arg constructor
    public OrderItem(int id, Menu menu, int quantity, Double price, Orders orders) {
        this.id = id;
        this.menu = menu;
        this.quantity = quantity;
        this.price = price;
        this.orders = orders;
    }

    // Custom constructor without id (for creation)
    public OrderItem(Menu menu, int quantity, Double price, Orders orders) {
        this.menu = menu;
        this.quantity = quantity;
        this.price = price;
        this.orders = orders;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Menu getMenu() {
        return menu;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Orders getOrders() {
        return orders;
    }

    public void setOrders(Orders orders) {
        this.orders = orders;
    }

    // equals() and hashCode()

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof OrderItem)) return false;
        OrderItem that = (OrderItem) o;
        return id == that.id &&
               quantity == that.quantity &&
               Objects.equals(menu, that.menu) &&
               Objects.equals(price, that.price) &&
               Objects.equals(orders, that.orders);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, menu, quantity, price, orders);
    }
}
