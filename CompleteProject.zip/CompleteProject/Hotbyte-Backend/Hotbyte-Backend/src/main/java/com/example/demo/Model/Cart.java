package com.example.demo.Model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @OneToOne
    private User user;

    @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<CartItem> cartitem = new ArrayList<>();

    private double totalprice;

    // No-arg constructor
    public Cart() {
    }

    // All-arg constructor
    public Cart(int id, User user, List<CartItem> cartitem, double totalprice) {
        this.id = id;
        this.user = user;
        this.cartitem = cartitem;
        this.totalprice = totalprice;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<CartItem> getCartitem() {
        return cartitem;
    }

    public void setCartitem(List<CartItem> cartitem) {
        this.cartitem = cartitem;
    }

    public double getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(double totalprice) {
        this.totalprice = totalprice;
    }

    // equals() and hashCode()

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Cart)) return false;
        Cart cart = (Cart) o;
        return id == cart.id &&
               Double.compare(cart.totalprice, totalprice) == 0 &&
               Objects.equals(user, cart.user) &&
               Objects.equals(cartitem, cart.cartitem);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, user, cartitem, totalprice);
    }
}
