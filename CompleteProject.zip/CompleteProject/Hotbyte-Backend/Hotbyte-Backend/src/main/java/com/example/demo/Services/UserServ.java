package com.example.demo.Services;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Exceptions.MenuNotFound;
import com.example.demo.Exceptions.OrdersNotFound;
import com.example.demo.Exceptions.UserNotFoundException;
import com.example.demo.Model.Cart;
import com.example.demo.Model.CartItem;
import com.example.demo.Model.Menu;
import com.example.demo.Model.OrderItem;
import com.example.demo.Model.Orders;
import com.example.demo.Model.Restaurant;
import com.example.demo.Model.User;
import com.example.demo.Model.Enum.Category;
import com.example.demo.Model.Enum.DietaryType;
import com.example.demo.Repository.CartItemRepo;
import com.example.demo.Repository.CartRepo;
import com.example.demo.Repository.MenuRepo;
import com.example.demo.Repository.OrdersRepo;
import com.example.demo.Repository.RestaurantRepo;
import com.example.demo.Repository.UserRepo;
import com.example.demo.Security.JwtUtil;
import com.example.demo.dto.OrderItemDTO;
import com.example.demo.dto.OrderSummaryDTO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;

@Service
public class UserServ {
	@Autowired
	private UserRepo userrepo;
	@Autowired
	private MenuRepo menurepo;
	@Autowired
	private OrdersRepo ordersrepo;
	@Autowired
	private CartRepo cartrepo;
	@Autowired
	private JwtUtil jwtutil;
	@Autowired
	private RestaurantRepo resrepo;
	@Autowired
	private CartItemRepo cartitemrepo;
	
	private int getUserIdFromRequest(HttpServletRequest request) {
		String authHeader=request.getHeader("Authorization");
		if(authHeader!=null&&authHeader.startsWith("Bearer ")) {
			String token=authHeader.substring(7);
			return jwtutil.extractId(token);
		}
		throw new RuntimeException("Authorization header is missing or invalid");
	}
	
	public List<Menu> getallmenu(){
		return menurepo.findAll();
	}
	
	public List<Menu> getbyrestaurantid(int resId){
		return menurepo.findAllByRestaurantId(resId);
	}
	
	public List<Menu> getMenuByName(String menuname){
		return menurepo.findByNameIgnoreCase(menuname);
	}
	
	public List<Menu> getMenuByCategory(Category category){
		return menurepo.findByCategory(category);
	}
	public List<Menu> getByPriceRange(double startprice,double lastprice){
		return menurepo.findByPriceBetween(startprice,lastprice);
	}
	
	public List<Menu> getMenusWithFilters(Category category, DietaryType dietary, Double minPrice, Double maxPrice) {
	    if (minPrice == null) minPrice = 0.0;
	    if (maxPrice == null) maxPrice = Double.MAX_VALUE;

	    if (category != null && dietary != null) {
	        return menurepo.findByCategoryAndDietaryTypeAndPriceBetween(category, dietary, minPrice, maxPrice);
	    } else if (category != null) {
	        return menurepo.findByCategoryAndPriceBetween(category, minPrice, maxPrice);
	    } else if (dietary != null) {
	        return menurepo.findByDietaryTypeAndPriceBetween(dietary, minPrice, maxPrice);
	    } else {
	        return menurepo.findByPriceBetween(minPrice, maxPrice);
	    }
	}
	
	public Menu getmenubyid(int menuid) {
		return menurepo.findById(menuid)
				.orElseThrow(()->new MenuNotFound("Menu not found"));
	}


	
	//Cart 
	
	@Transactional
	public CartItem addToCart(HttpServletRequest request, int menuId, int quantity) {
	    int userId = getUserIdFromRequest(request);

	    User user = userrepo.findById(userId)
	        .orElseThrow(() -> new UserNotFoundException("User is invalid"));

	    Menu menu = menurepo.findById(menuId)
	        .orElseThrow(() -> new MenuNotFound("Menu ID not found"));

	    Cart cart = cartrepo.findByUserId(userId)
	        .orElseGet(() -> {
	            Cart newCart = new Cart();
	            newCart.setUser(user);
	            return cartrepo.save(newCart);
	        });

	    Optional<CartItem> existingItemOpt = cart.getCartitem().stream()
	        .filter(item -> item.getMenu().getId() == menuId)
	        .findFirst();

	    CartItem item;

	    if (existingItemOpt.isPresent()) {
	        item = existingItemOpt.get();
	        item.setQuantity(item.getQuantity() + quantity);
	        item.setPrice(item.getQuantity() * menu.getPrice());
	    } else {
	        item = new CartItem();
	        item.setCart(cart);
	        item.setMenu(menu);
	        item.setQuantity(quantity);
	        item.setPrice(quantity * menu.getPrice());
	        cart.getCartitem().add(item);
	    }

	    cart.setTotalprice(
	        cart.getCartitem().stream().mapToDouble(CartItem::getPrice).sum()
	    );

	    cartitemrepo.save(item); 
	    cartrepo.save(cart);     

	    return item;
	}
	
	
	//View Cart
	
	public Cart getCartbyUserId(HttpServletRequest request) {
		int userId = getUserIdFromRequest(request);
		return cartrepo.findByUserId(userId)

				.orElseThrow(()->new RuntimeException("Empty Cart"));
	}
	public CartItem updateCartItemQuantity(int itemid,int quantity) {
		CartItem item=cartitemrepo.findById(itemid).orElseThrow(()->new RuntimeException("Item not Found"));
		item.setQuantity(quantity);
		item.setPrice(quantity*item.getMenu().getPrice());
		return cartitemrepo.save(item);
		}
	
	
//remove Cart
	@Transactional
	public void removeItem(int itemId) {
	    CartItem item = cartitemrepo.findById(itemId)
	        .orElseThrow(() -> new RuntimeException("CartItem not found"));

	    Cart cart = item.getCart();

	    if (cart.getCartitem().remove(item)) {
	        cart.setTotalprice(
	            cart.getCartitem().stream().mapToDouble(CartItem::getPrice).sum()
	        );

	        cartrepo.save(cart);
	    }
	}
	
	//update cart
	public Cart updateQuantity(int cartItemId, int quantity) {
	    CartItem cartItem = cartitemrepo.findById(cartItemId)
	        .orElseThrow(() -> new RuntimeException("Cart item not found"));

	    cartItem.setQuantity(quantity);
	    cartItem.setPrice(quantity * cartItem.getMenu().getPrice());
	    cartitemrepo.save(cartItem);

	    // ✅ Recalculate total price of the cart
	    Cart cart = cartItem.getCart();
	    double total = cart.getCartitem().stream()
	        .mapToDouble(CartItem::getPrice)
	        .sum();
	    cart.setTotalprice(total);
	    
	    cartrepo.save(cart);
	    // ✅ Save updated totalprice

	    return cart; // ✅ Return updated cart
	}



		
	//order
	public Orders checkout(HttpServletRequest request, Orders order) {
	    int userId = getUserIdFromRequest(request);
	    
	    Cart cart = cartrepo.findByUserId(userId)
	        .orElseThrow(() -> new UserNotFoundException("Invalid user"));

	    Orders orders = new Orders();
	    orders.setUser(cart.getUser());

	    List<OrderItem> orderItems = new ArrayList<>();
	    for (CartItem ci : cart.getCartitem()) {
	        OrderItem orderItem = new OrderItem(ci.getMenu(), ci.getQuantity(), ci.getPrice(), orders);
	        orderItems.add(orderItem);
	    }
	    orders.setOrderitem(orderItems);
	    orders.setOrderitem(orderItems);
	    
	    orders.setShippingAddress(order.getShippingAddress());
	    orders.setPaymentMethod(order.getPaymentMethod());
	    orders.setTotalAmount(cart.getTotalprice());
	    orders.setStatus("PENDING");
	    orders.setOrderTime(LocalDateTime.now());
	    Restaurant restaurant = cart.getCartitem().get(0).getMenu().getRestaurant();
	    orders.setRestaurant(restaurant);
	    ordersrepo.save(orders);

	    
	    cart.getCartitem().clear();
	    cart.setTotalprice(0.0);
	    cartrepo.save(cart);

	    return orders;
	}
	public OrderSummaryDTO viewOrderSummary(int orderId) {
	    Orders orders = ordersrepo.findById(orderId)
	            .orElseThrow(() -> new OrdersNotFound("Order not found"));

	    List<OrderItemDTO> itemDTOs = orders.getOrderitem().stream()
	            .map(items -> new OrderItemDTO(
	                    items.getMenu().getName(),
	                    items.getQuantity(),
	                    items.getPrice()))
	            .toList();

	    return new OrderSummaryDTO(
	            orders.getId(),
	            orders.getUser().getName(),
	            orders.getRestaurant().getName(),
	            orders.getShippingAddress(),
	            orders.getPaymentMethod(),
	            orders.getTotalAmount(),
	            orders.getOrderTime(),
	            orders.getStatus(),
	            itemDTOs
	    );
	}

	
	public List<Orders> viewAllOrder(HttpServletRequest request){
		int userId = getUserIdFromRequest(request);
		
		return ordersrepo.findByUserId(userId);
				
	}
	public List<Menu> searchMenuByKeyword(String keyword) {
	    return menurepo.findByNameContainingIgnoreCase(keyword);
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
