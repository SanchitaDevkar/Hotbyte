package com.example.demo.Model.Enum;

public enum Category {
	    STARTERS,
	    MAIN_COURSE,
	    DESSERTS,
	    BEVERAGES,
	    SNACKS,
	    SALADS,
	    SOUPS

}
