package com.example.demo.Services;


import org.springframework.security.core.AuthenticationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.Model.Admin;
import com.example.demo.Model.Restaurant;
import com.example.demo.Model.User;
import com.example.demo.Repository.AdminRepo;
import com.example.demo.Repository.RestaurantRepo;
import com.example.demo.Repository.UserRepo;
import com.example.demo.Security.JwtUtil;
import com.example.demo.dto.LoginRequest;
import com.example.demo.dto.LoginResponse;
import com.example.demo.dto.RegisterRequest;

@Service
public class AuthService {


	private final AuthenticationManager authenticationmanager;
	private final JwtUtil jwtUtil;
	private final UserRepo userrepo;
	private final RestaurantRepo resrepo;
	private final AdminRepo adminrepo;
	@Autowired
	private PasswordEncoder passwordencoder;
	public AuthService(AuthenticationManager authenticationmanager, JwtUtil jwtUtil, UserRepo userrepo,
			RestaurantRepo resrepo, AdminRepo adminrepo) {
		super();
		this.authenticationmanager = authenticationmanager;
		this.jwtUtil = jwtUtil;
		this.userrepo = userrepo;
		this.resrepo = resrepo;
		this.adminrepo = adminrepo;
	
	}
	
	public String register(RegisterRequest registerreq) {
		String role=registerreq.getRole().toUpperCase();
		
		switch(role) {
			case "USER":
				User user=new User();
				user.setName(registerreq.getName());
				user.setContact(registerreq.getContact());
				user.setEmail(registerreq.getEmail());
				user.setPassword(passwordencoder.encode(registerreq.getPassword()));
				user.setRole("USER");
				userrepo.save(user);
				return "User registered successfully";
			
			case "RESTAURANT":
				Restaurant res=new Restaurant();
				res.setName(registerreq.getName());
				res.setContact(registerreq.getContact());
				res.setEmail(registerreq.getEmail());
				res.setPassword(passwordencoder.encode(registerreq.getPassword()));
				res.setRole("RESTAURANT");
				resrepo.save(res);
				return"Restaurant registered successfully";
				
			case "ADMIN":
	            Admin admin = new Admin();
	            
	            admin.setName(registerreq.getName());
	            admin.setContactsph(registerreq.getContact());
	            admin.setEmail(registerreq.getEmail());
	            admin.setPassword(passwordencoder.encode(registerreq.getPassword()));
	            admin.setRole("ADMIN");
	            adminrepo.save(admin);
	            return "Admin registered successfully";
			 default:
	                throw new IllegalArgumentException("Invalid role: " + role);
			
		}
	}
		
	public LoginResponse login(LoginRequest logi) {
	    try {
	        authenticationmanager.authenticate(
	            new UsernamePasswordAuthenticationToken(logi.getEmail(), logi.getPassword())
	        );

	        String token = jwtUtil.generateToken(logi.getEmail());
	        return new LoginResponse(token);

	    } catch (AuthenticationException e) {
	        throw new RuntimeException("Invalid email or password");
	    }
	}

	
	
	

}
