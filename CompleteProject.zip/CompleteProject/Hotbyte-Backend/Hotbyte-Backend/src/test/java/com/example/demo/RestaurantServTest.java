package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.Model.*;
import com.example.demo.Repository.*;
import com.example.demo.Security.JwtUtil;
import com.example.demo.Services.RestaurantServ;
import com.example.demo.Exceptions.*;

import jakarta.servlet.http.HttpServletRequest;

@SpringBootTest
public class RestaurantServTest {

    @InjectMocks
    private RestaurantServ restaurantServ;

    @Mock
    private RestaurantRepo restaurantRepo;

    @Mock
    private MenuRepo menuRepo;

    @Mock
    private OrdersRepo ordersRepo;

    @Mock
    private CartItemRepo cartItemRepo;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private HttpServletRequest request;

    private final int mockRestaurantId = 1;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        when(request.getHeader("Authorization")).thenReturn("Bearer testtoken");
        when(jwtUtil.extractId("testtoken")).thenReturn(mockRestaurantId);
    }

    @Test
    public void testUpdateInStock_success() {
        Restaurant res = new Restaurant();
        res.setId(mockRestaurantId);
        Menu menu = new Menu();
        menu.setAvailable(false);
        menu.setRestaurant(res);

        when(restaurantRepo.findById(mockRestaurantId)).thenReturn(Optional.of(res));
        when(menuRepo.findById(1)).thenReturn(Optional.of(menu));

        String result = restaurantServ.UpdateInStock(request, 1);
        assertEquals("Menu is marked as InStock", result);
    }

    @Test
    public void testUpdateInStock_alreadyAvailable() {
        Restaurant res = new Restaurant();
        res.setId(mockRestaurantId);
        Menu menu = new Menu();
        menu.setAvailable(true);
        menu.setRestaurant(res);

        when(restaurantRepo.findById(mockRestaurantId)).thenReturn(Optional.of(res));
        when(menuRepo.findById(1)).thenReturn(Optional.of(menu));

        assertThrows(RuntimeException.class, () -> restaurantServ.UpdateInStock(request, 1));
    }

    @Test
    public void testGetProfileRes_success() {
        Restaurant res = new Restaurant();
        res.setId(mockRestaurantId);
        res.setName("Mock Restaurant");

        when(restaurantRepo.findById(mockRestaurantId)).thenReturn(Optional.of(res));

        Restaurant result = restaurantServ.getprofileRes(request);
        assertEquals("Mock Restaurant", result.getName());
    }

    @Test
    public void testDeleteById_MenuNotFound() {
        Restaurant res = new Restaurant();
        res.setId(mockRestaurantId);

        when(restaurantRepo.findById(mockRestaurantId)).thenReturn(Optional.of(res));
        when(menuRepo.findById(10)).thenReturn(Optional.empty());

        assertThrows(MenuNotFound.class, () -> restaurantServ.DeleteById(request, 10));
    }

    @Test
    public void testSetOrderAsCancelled_success() {
        Restaurant res = new Restaurant();
        res.setId(mockRestaurantId);

        Orders order = new Orders();
        order.setRestaurant(res);
        order.setStatus("PENDING");

        when(restaurantRepo.findById(mockRestaurantId)).thenReturn(Optional.of(res));
        when(ordersRepo.findById(1)).thenReturn(Optional.of(order));

        String result = restaurantServ.setOrderAsCancel(request, 1);
        assertEquals("Status has been updated To Cancelled", result);
    }

    @Test
    public void testHistoryOfOrder() {
        List<Orders> mockOrders = List.of(new Orders(), new Orders());
        when(ordersRepo.findAllByRestaurantIdAndStatus(mockRestaurantId, "DELIVERED")).thenReturn(mockOrders);

        List<Orders> result = restaurantServ.HistoryOfOrder(request);
        assertEquals(2, result.size());
    }
}